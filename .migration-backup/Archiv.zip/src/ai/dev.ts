
import { config } from 'dotenv';
config();

import '@/ai/flows/substance-interaction-risk-assessment.ts';
import '@/ai/flows/substance-safety-chat.ts';
import '@/ai/flows/generate-substance-education-video.ts';
import '@/ai/flows/app-support-chat.ts';
import '@/ai/flows/moderate-message.ts';
import '@/ai/flows/text-to-speech.ts';
import '@/ai/flows/estimate-dose-flow.ts';
import '@/ai/flows/identify-pill-flow.ts';
